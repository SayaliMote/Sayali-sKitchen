from django.shortcuts import redirect, render, get_object_or_404
from shop .models import Product
from .models import Cart, CartItem
from django.core.exceptions import ObjectDoesNotExist
from django.conf import settings
import stripe
from order.models import Order, OrderItem
from vouchers.models import Voucher
from vouchers.forms import VoucherApplyForm
from decimal import Decimal


# Create your views here.
def _cart_id(request):
    if request.user.is_authenticated:
        return str(request.user.id)  # Use user ID for logged-in users
    else:
        cart = request.session.session_key
        if not cart:
            cart = request.session.create()
        return cart


def add_cart(request, product_id):
    product = Product.objects.get(id=product_id)

    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        cart, created = Cart.objects.get_or_create(cart_id=_cart_id(request))

    cart_item, created = CartItem.objects.get_or_create(product=product, cart=cart)
    
    if not created and cart_item.quantity < cart_item.product.stock:
        cart_item.quantity += 1
        cart_item.save()

    return redirect('cart:cart_detail')

def cart_detail(request, total=0, counter=0, cart_items=None):
    discount = 0
    new_total = 0
    voucher = None

    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user=request.user)
    else:
        cart, created = Cart.objects.get_or_create(cart_id=_cart_id(request))

    cart_items = CartItem.objects.filter(cart=cart, active=True)

    for cart_item in cart_items:
        total += (cart_item.product.price * cart_item.quantity)
        counter += cart_item.quantity

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total': total,
        'counter': counter,
        'new_total': new_total,
        'voucher': voucher,
        'discount': discount
    })


def cart_remove(request, product_id):
    if request.user.is_authenticated:
        cart = Cart.objects.get(user=request.user)
    else:
        cart = Cart.objects.get(cart_id=_cart_id(request))

    product = get_object_or_404(Product, id=product_id)
    cart_item = CartItem.objects.get(product=product, cart=cart)

    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.save()
    else:
        cart_item.delete()

    return redirect('cart:cart_detail')

def full_remove(request, product_id):
    cart = Cart.objects.get(cart_id=_cart_id(request))
    product = get_object_or_404(Product, id=product_id)
    cart_item = CartItem.objects.get(product=product, cart=cart)
    cart_item.delete()
    return redirect('cart:cart_detail')









