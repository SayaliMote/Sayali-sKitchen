from .models import CartItem, Cart

def cart_counter(request):
    cart_count = 0

    if request.user.is_authenticated:
        cart = Cart.objects.filter(user=request.user).first()
    else:
        cart = Cart.objects.filter(cart_id=request.session.session_key).first()

    if cart:
        cart_count = CartItem.objects.filter(cart=cart, active=True).count()

    return {'cart_count': cart_count}
